import { and, eq, desc, isNull } from 'drizzle-orm';
import { B as BOARD_QUADRANTS, m as BOARD_QUADRANT_LABELS, C as CONFIG, n as nowMs, o as db, p as relationshipInsights, q as contacts, v as activities, w as deals, x as RELATIONSHIP_REPAIR, y as promises, z as boardPins } from './nitro.mjs';

const DAY_MS = CONFIG.time.dayMs;
const URGENT_PROMISE_PATTERN = /每日|每天|立即|第一时间|盯|催|跟进|asap|daily|immediately/i;
const FUTURE_PROMISE_PATTERN = /下一单|下次发货|批量返单|下回|next order|future/i;
const ESCALATION_WEIGHT = 1e3;
const NEGATIVE_HEALTH_LEVEL_WORDS = [
  "frustrated",
  "at risk",
  "delayed",
  "delay",
  "risk",
  "angry",
  "upset",
  "bad",
  "poor",
  "\u6076\u5316",
  "\u5EF6\u8BEF",
  "\u5EF6\u8FDF",
  "\u98CE\u9669",
  "\u544A\u6025",
  "\u7126\u8651",
  "\u4E0D\u6EE1",
  "\u7D27\u5F20",
  "\u7CDF\u7CD5"
];
function isNegativeHealth(side) {
  if (typeof side.level === "string") {
    const level = side.level.toLowerCase();
    if (NEGATIVE_HEALTH_LEVEL_WORDS.some((word) => level.includes(word))) return true;
  }
  return typeof side.score === "number" && side.score < 40;
}
async function contactsInPoorHealth() {
  var _a;
  const rows = await db().select({
    contactId: relationshipInsights.contactId,
    payload: relationshipInsights.payload
  }).from(relationshipInsights).where(and(eq(relationshipInsights.kind, "dual_track"), eq(relationshipInsights.status, "applied"))).orderBy(desc(relationshipInsights.createdAt));
  const byContact = /* @__PURE__ */ new Map();
  for (const row of rows) {
    if (byContact.has(row.contactId)) continue;
    const side = (_a = row.payload) == null ? void 0 : _a.transaction_health;
    if (!side || !isNegativeHealth(side)) continue;
    byContact.set(row.contactId, typeof side.level === "string" && side.level ? side.level : "\u8D1F\u9762");
  }
  return byContact;
}
function daysSince(at, now) {
  if (!at) return 0;
  return Math.max(0, Math.floor((now - at) / DAY_MS));
}
async function pinnedQuadrants() {
  const rows = await db().select().from(boardPins);
  const table = /* @__PURE__ */ new Map();
  for (const row of rows) {
    table.set(`${row.itemType}:${row.itemId}`, row.quadrant);
  }
  return table;
}
function pinKey(type, id) {
  return `${type}:${id}`;
}
async function taskItems(now, poorHealth) {
  const rows = await db().select({
    id: activities.id,
    title: activities.title,
    body: activities.body,
    dueAt: activities.dueAt,
    contactId: activities.contactId,
    contactFirst: contacts.firstName,
    contactLast: contacts.lastName
  }).from(activities).leftJoin(contacts, eq(activities.contactId, contacts.id)).where(and(eq(activities.kind, "task"), isNull(activities.completedAt))).orderBy(activities.dueAt).limit(CONFIG.board.taskLimit);
  return rows.map((row) => {
    var _a;
    const overdueDays = row.dueAt ? daysSince(row.dueAt, now) : 0;
    const healthLevel = row.contactId ? poorHealth.get(row.contactId) : void 0;
    const badge = row.dueAt ? overdueDays > 0 ? `\u903E\u671F ${overdueDays} \u5929` : "\u672A\u5230\u671F" : "\u65E0\u622A\u6B62\u65E5";
    return {
      type: "task",
      id: row.id,
      title: row.title,
      detail: row.contactFirst ? `${row.contactFirst}${(_a = row.contactLast) != null ? _a : ""}` : null,
      badge: healthLevel ? `${badge} \xB7 \u5BA2\u6237${healthLevel}` : badge,
      to: row.contactId ? `/contacts/${row.contactId}` : "/",
      // 逾期才是紧急；没有截止日的任务一律算不紧急，靠拖拽决定——
      // 除非对方事务健康度已跌到负面，那时跟进本身就是救火。
      inferred: healthLevel || overdueDays > 0 ? "urgent_important" : "important",
      weight: healthLevel ? ESCALATION_WEIGHT + overdueDays : overdueDays
    };
  });
}
async function dealItems(now) {
  const rows = await db().select().from(deals).where(and(isNull(deals.archivedAt), eq(deals.status, "open"))).orderBy(desc(deals.updatedAt)).limit(CONFIG.board.dealLimit);
  return rows.map((row) => {
    var _a;
    const stalledDays = daysSince((_a = row.stageChangedAt) != null ? _a : row.updatedAt, now);
    const stalled = stalledDays >= CONFIG.board.stalledDealDays;
    return {
      type: "deal",
      id: row.id,
      title: row.name,
      detail: `\u5546\u673A \xB7 ${row.stage}`,
      badge: stalled ? `\u505C\u7559 ${stalledDays} \u5929` : null,
      to: `/deals/${row.id}`,
      // 停滞太久就是紧急：要么推一下，要么关掉。
      inferred: stalled ? "urgent_important" : "important",
      weight: stalledDays
    };
  });
}
async function contactItems() {
  const rows = await db().select().from(contacts).where(isNull(contacts.archivedAt)).orderBy(desc(contacts.updatedAt)).limit(CONFIG.board.contactLimit);
  return rows.filter((row) => row.relationshipState !== null).map((row) => {
    var _a;
    const isKeyAccount = row.relationshipState === "\u91CD\u70B9\u7EF4\u62A4";
    return {
      type: "contact",
      id: row.id,
      title: `${row.firstName}${(_a = row.lastName) != null ? _a : ""}`,
      detail: row.repairNote ? `${row.relationshipState}\uFF1A${row.repairNote}` : row.relationshipState,
      // badge 直接用状态原文：第四象限的词条显示「{姓名}{状态}」整句，
      // 比如「David McGowan关系待修复」；重点维护是好事，不挂红字。
      badge: row.relationshipState === RELATIONSHIP_REPAIR || !isKeyAccount ? row.relationshipState : null,
      to: `/contacts/${row.id}`,
      inferred: isKeyAccount ? "important" : "neither",
      weight: 0
    };
  });
}
async function promiseItems(poorHealth) {
  const rows = await db().select().from(promises).where(eq(promises.status, "open")).orderBy(desc(promises.createdAt)).limit(CONFIG.board.promiseLimit);
  return rows.map((row) => {
    const ours = row.direction === "ours";
    const healthLevel = poorHealth.get(row.contactId);
    const text = [row.title, row.detail, row.dueHint].filter(Boolean).join(" ");
    const isFuture = FUTURE_PROMISE_PATTERN.test(text);
    const escalate = Boolean(ours && healthLevel && !isFuture && URGENT_PROMISE_PATTERN.test(text));
    return {
      type: "promise",
      id: row.id,
      title: row.title,
      detail: [
        ours ? "\u6211\u65B9\u6B20" : "\u5BF9\u65B9\u8BB8",
        row.dueHint,
        row.detail
      ].filter(Boolean).join(" \xB7 "),
      badge: escalate && healthLevel ? `\u5BA2\u6237${healthLevel}` : null,
      to: `/contacts/${row.contactId}`,
      inferred: escalate ? "urgent_important" : ours ? "important" : "neither",
      weight: escalate ? ESCALATION_WEIGHT : 0
    };
  });
}
function applyPins(items, pins) {
  return items.map((item) => {
    const pinned = pins.get(pinKey(item.type, item.id));
    if (!pinned) return { ...item, quadrant: item.inferred, pinned: false };
    return { ...item, quadrant: pinned, pinned: true };
  });
}
async function board(now = nowMs()) {
  const poorHealth = await contactsInPoorHealth();
  const [tasks, dealRows, contactRows, promiseRows, pins] = await Promise.all([
    taskItems(now, poorHealth),
    dealItems(now),
    contactItems(),
    promiseItems(poorHealth),
    pinnedQuadrants()
  ]);
  const items = applyPins([...tasks, ...dealRows, ...contactRows, ...promiseRows], pins);
  const columns = BOARD_QUADRANTS.map((quadrant) => ({
    quadrant,
    label: BOARD_QUADRANT_LABELS[quadrant],
    items: items.filter((item) => item.quadrant === quadrant).sort((a, b) => b.weight - a.weight || a.title.localeCompare(b.title)).slice(0, CONFIG.board.maxItemsPerQuadrant)
  }));
  return {
    columns,
    pinnedCount: items.filter((item) => item.pinned).length
  };
}
async function pinItem(input) {
  if (!BOARD_QUADRANTS.includes(input.quadrant)) {
    return { ok: false, reason: "\u6CA1\u6709\u8FD9\u4E2A\u8C61\u9650\u3002", pinned: false };
  }
  if (input.quadrant === input.inferred) {
    await db().delete(boardPins).where(and(eq(boardPins.itemType, input.type), eq(boardPins.itemId, input.id)));
    return { ok: true, reason: "\u5DF2\u6062\u590D\u81EA\u52A8\u5224\u5B9A\u3002", pinned: false };
  }
  await db().insert(boardPins).values({
    itemType: input.type,
    itemId: input.id,
    quadrant: input.quadrant,
    updatedAt: nowMs()
  }).onDuplicateKeyUpdate({
    set: { quadrant: input.quadrant, updatedAt: nowMs() }
  });
  return { ok: true, reason: "\u5DF2\u79FB\u52A8\u3002", pinned: true };
}

export { board as b, pinItem as p };
//# sourceMappingURL=board.mjs.map
