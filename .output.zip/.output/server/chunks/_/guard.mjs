import { aA as isError, aB as databaseConfigured, D as createError } from './nitro.mjs';

async function guarded(run) {
  try {
    return await run();
  } catch (error) {
    if (isError(error)) throw error;
    if (!databaseConfigured()) {
      throw createError({
        statusCode: 503,
        statusMessage: "\u6570\u636E\u5E93\u672A\u914D\u7F6E\uFF1A\u8BF7\u5728 .env \u4E2D\u586B\u5199 DATABASE_URL\u3002"
      });
    }
    throw createError({
      statusCode: 500,
      statusMessage: error instanceof Error ? error.message : "\u670D\u52A1\u5668\u5185\u90E8\u9519\u8BEF\u3002"
    });
  }
}
function notFound(message) {
  return createError({ statusCode: 404, statusMessage: message });
}
function badRequest(message) {
  return createError({ statusCode: 400, statusMessage: message });
}

export { badRequest as b, guarded as g, notFound as n };
//# sourceMappingURL=guard.mjs.map
