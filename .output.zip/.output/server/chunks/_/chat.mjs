import { eq, asc, and, isNull, desc } from 'drizzle-orm';
import { o as db, aC as conversations, aD as newId, aE as messages, n as nowMs, aF as parseToolCalls } from './nitro.mjs';

function toConversation(row) {
  return { ...row };
}
function toMessage(row) {
  return {
    ...row,
    toolCalls: parseToolCalls(row.toolCalls)
  };
}
async function listConversations(input) {
  const filters = [];
  if (input.contactId) filters.push(eq(conversations.contactId, input.contactId));
  else if (input.companyId) filters.push(eq(conversations.companyId, input.companyId));
  else if (input.dealId) filters.push(eq(conversations.dealId, input.dealId));
  else
    filters.push(
      and(
        isNull(conversations.contactId),
        isNull(conversations.companyId),
        isNull(conversations.dealId)
      )
    );
  const rows = await db().select().from(conversations).where(and(...filters)).orderBy(desc(conversations.lastMessageAt)).limit(50);
  return rows.map(toConversation);
}
async function getConversation(id) {
  const [row] = await db().select().from(conversations).where(eq(conversations.id, id)).limit(1);
  return row ? toConversation(row) : null;
}
async function createConversation(input) {
  const id = newId();
  const at = nowMs();
  await db().insert(conversations).values({
    id,
    contactId: input.contactId,
    companyId: input.companyId,
    dealId: input.dealId,
    title: input.title,
    createdAt: at,
    lastMessageAt: at
  });
  const created = await getConversation(id);
  if (!created) throw new Error("\u4F1A\u8BDD\u521B\u5EFA\u5931\u8D25\u3002");
  return created;
}
async function conversationMessages(conversationId, limit) {
  const rows = await db().select().from(messages).where(eq(messages.conversationId, conversationId)).orderBy(asc(messages.createdAt)).limit(limit);
  return rows.map(toMessage);
}
async function attachConversation(input) {
  await db().update(conversations).set({
    contactId: input.contactId,
    companyId: input.companyId,
    ...input.title ? { title: input.title } : {}
  }).where(eq(conversations.id, input.conversationId));
}
async function appendMessage(input) {
  var _a;
  const id = newId();
  const at = nowMs();
  await db().insert(messages).values({
    id,
    conversationId: input.conversationId,
    role: input.role,
    content: input.content,
    reasoning: (_a = input.reasoning) != null ? _a : null,
    toolCalls: input.toolCalls && input.toolCalls.length > 0 ? input.toolCalls : null,
    createdAt: at
  });
  await db().update(conversations).set({ lastMessageAt: at }).where(eq(conversations.id, input.conversationId));
  const [row] = await db().select().from(messages).where(eq(messages.id, id)).limit(1);
  if (!row) throw new Error("\u6D88\u606F\u5199\u5165\u5931\u8D25\u3002");
  return toMessage(row);
}

export { appendMessage as a, conversationMessages as b, createConversation as c, attachConversation as d, getConversation as g, listConversations as l };
//# sourceMappingURL=chat.mjs.map
