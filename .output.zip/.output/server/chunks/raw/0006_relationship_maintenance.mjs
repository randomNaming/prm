// ROLLUP_NO_REPLACE 
 const _0006_relationship_maintenance = "-- 关系维护：把「这个客户的关系现在是什么状态」记在联系人上。\n-- 留空 = 正常关系，进「长期养着」的池子（节日问候、群发营销）。\n-- 填了「关系待修复」时，用 repair_note 写清要修什么。\n--\n-- field_defs 里的登记（关系维护 / 修复说明）由进程启动时的 seedBuiltinFields 补齐，\n-- 这里只管加列。\nALTER TABLE `contacts` ADD COLUMN `relationship_state` VARCHAR(32);\n--> statement-breakpoint\nALTER TABLE `contacts` ADD COLUMN `repair_note` VARCHAR(191);\n";

export { _0006_relationship_maintenance as default };
//# sourceMappingURL=0006_relationship_maintenance.mjs.map
