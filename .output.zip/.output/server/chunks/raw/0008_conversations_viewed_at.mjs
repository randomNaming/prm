// ROLLUP_NO_REPLACE 
 const _0008_conversations_viewed_at = "-- 聊天留底的已读标记：详情页「聊天留底」标签上红点的依据。\n-- null = 还没看过；打开该标签后由 /api/intake-viewed 写入时间戳。\n--\n-- 存量会话一律视为已看：加这列之前导入的都不算「新到的」，\n-- 以后每次新导入从 null 开始，红点只提示真正没看过的。\nALTER TABLE `conversations` ADD COLUMN `viewed_at` BIGINT;\n--> statement-breakpoint\nUPDATE `conversations` SET `viewed_at` = ROUND(UNIX_TIMESTAMP(NOW(3)) * 1000) WHERE `viewed_at` IS NULL;\n";

export { _0008_conversations_viewed_at as default };
//# sourceMappingURL=0008_conversations_viewed_at.mjs.map
