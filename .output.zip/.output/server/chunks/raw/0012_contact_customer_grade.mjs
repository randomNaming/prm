// ROLLUP_NO_REPLACE 
 const _0012_contact_customer_grade = "-- 客户等级：商务价值的分级标签（A 类潜力买家 / B 类稳定客户 / C 类一般客户，可增词）。\n-- 智能体可以建议，人工可改 —— 覆盖规则沿用事实通道：人工值永不被覆盖。\nALTER TABLE `contacts` ADD COLUMN `customer_grade` VARCHAR(32);\n";

export { _0012_contact_customer_grade as default };
//# sourceMappingURL=0012_contact_customer_grade.mjs.map
