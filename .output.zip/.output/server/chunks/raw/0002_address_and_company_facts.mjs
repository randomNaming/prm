// ROLLUP_NO_REPLACE 
 const _0002_address_and_company_facts = "ALTER TABLE `contacts` ADD COLUMN `address` VARCHAR(191) AFTER `wechat_id`;\n--> statement-breakpoint\nALTER TABLE `companies` ADD COLUMN `address` VARCHAR(191) AFTER `industry`;\n--> statement-breakpoint\nCREATE TABLE `company_facts` (\n\t`id` VARCHAR(36) PRIMARY KEY,\n\t`company_id` VARCHAR(36) NOT NULL,\n\t`field` VARCHAR(32) NOT NULL,\n\t`value` TEXT NOT NULL,\n\t`status` VARCHAR(16) NOT NULL,\n\t`evidence` JSON NOT NULL,\n\t`source` VARCHAR(16) NOT NULL,\n\t`decided_at` BIGINT,\n\t`created_at` BIGINT NOT NULL,\n\tCONSTRAINT `fk_company_facts_company` FOREIGN KEY (`company_id`)\n\t\tREFERENCES `companies`(`id`) ON DELETE CASCADE,\n\tINDEX `company_facts_field` (`company_id`, `field`, `status`)\n);\n";

export { _0002_address_and_company_facts as default };
//# sourceMappingURL=0002_address_and_company_facts.mjs.map
