import { c as defineEventHandler, a$ as megrezEnabled, D as createError, b0 as megrezConfig, g as getQuery, b1 as getCookie, b2 as deleteCookie, b3 as setCookie, b4 as cookieOptions, b5 as SESSION_COOKIE, b6 as sendRedirect, b7 as STATE_COOKIE, b8 as NEXT_COOKIE } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'zod';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const callback = defineEventHandler(async (event) => {
  if (!megrezEnabled()) {
    throw createError({ statusCode: 503, statusMessage: "\u5929\u6743\u672A\u914D\u7F6E\u3002" });
  }
  const config = megrezConfig();
  const query = getQuery(event);
  const expectedState = getCookie(event, STATE_COOKIE);
  const next = getCookie(event, NEXT_COOKIE) || "/";
  deleteCookie(event, STATE_COOKIE, { path: "/" });
  deleteCookie(event, NEXT_COOKIE, { path: "/" });
  if (!expectedState || typeof query.state !== "string" || query.state !== expectedState) {
    throw createError({ statusCode: 400, statusMessage: "\u767B\u5F55\u72B6\u6001\u6821\u9A8C\u5931\u8D25\uFF0C\u8BF7\u91CD\u65B0\u53D1\u8D77\u767B\u5F55\u3002" });
  }
  if (typeof query.error === "string") {
    throw createError({ statusCode: 403, statusMessage: "\u4F60\u5728\u5929\u6743\u53D6\u6D88\u4E86\u672C\u6B21\u6388\u6743\u3002" });
  }
  if (typeof query.code !== "string" || !query.code) {
    throw createError({ statusCode: 400, statusMessage: "\u56DE\u8C03\u7F3A\u5C11\u6388\u6743\u7801\u3002" });
  }
  let payload;
  try {
    payload = await $fetch(`${config.base}/oauth/token`, {
      method: "POST",
      body: {
        grant_type: "authorization_code",
        code: query.code,
        client_id: config.clientId,
        client_secret: config.clientSecret
      }
    });
  } catch {
    throw createError({ statusCode: 502, statusMessage: "\u5411\u5929\u6743\u6362\u53D6\u7968\u636E\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002" });
  }
  if (!(payload == null ? void 0 : payload.access_token)) {
    throw createError({ statusCode: 502, statusMessage: "\u5929\u6743\u6CA1\u6709\u8FD4\u56DE\u8BBF\u95EE\u7968\u636E\u3002" });
  }
  const maxAge = Number.isFinite(payload.expires_in) && payload.expires_in > 0 ? payload.expires_in : 8 * 3600;
  setCookie(event, SESSION_COOKIE, payload.access_token, cookieOptions(event, maxAge));
  const target = next.startsWith("/") && !next.startsWith("//") ? next : "/";
  return sendRedirect(event, target, 302);
});

export { callback as default };
//# sourceMappingURL=callback.mjs.map
