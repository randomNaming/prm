import { c as defineEventHandler, a$ as megrezEnabled, D as createError, b0 as megrezConfig, g as getQuery, b3 as setCookie, b4 as cookieOptions, b7 as STATE_COOKIE, b8 as NEXT_COOKIE, b6 as sendRedirect } from '../../_/nitro.mjs';
import { randomUUID } from 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'zod';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const login = defineEventHandler((event) => {
  if (!megrezEnabled()) {
    throw createError({
      statusCode: 503,
      statusMessage: "\u5929\u6743\u672A\u914D\u7F6E\uFF1A\u8BF7\u5728 .env \u91CC\u586B\u5199 MEGREZ_BASE / CLIENT_ID / CLIENT_SECRET / REDIRECT_URI\u3002"
    });
  }
  const config = megrezConfig();
  const requested = getQuery(event).redirect;
  const next = typeof requested === "string" && requested.startsWith("/") && !requested.startsWith("//") ? requested : "/";
  const state = randomUUID();
  setCookie(event, STATE_COOKIE, state, cookieOptions(event, 600));
  setCookie(event, NEXT_COOKIE, next, cookieOptions(event, 600));
  const params = new URLSearchParams({
    client_id: config.clientId,
    redirect_uri: config.redirectUri,
    state
  });
  return sendRedirect(event, `${config.base}/oauth/authorize?${params.toString()}`, 302);
});

export { login as default };
//# sourceMappingURL=login.mjs.map
