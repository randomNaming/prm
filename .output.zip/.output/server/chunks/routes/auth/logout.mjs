import { c as defineEventHandler, b2 as deleteCookie, a$ as megrezEnabled, b6 as sendRedirect, b9 as getRequestHeader, b0 as megrezConfig, b5 as SESSION_COOKIE, b7 as STATE_COOKIE, b8 as NEXT_COOKIE } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'zod';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const logout = defineEventHandler((event) => {
  var _a, _b, _c;
  deleteCookie(event, SESSION_COOKIE, { path: "/" });
  deleteCookie(event, STATE_COOKIE, { path: "/" });
  deleteCookie(event, NEXT_COOKIE, { path: "/" });
  if (!megrezEnabled()) return sendRedirect(event, "/", 302);
  const proto = ((_b = ((_a = getRequestHeader(event, "x-forwarded-proto")) != null ? _a : "http").split(",")[0]) == null ? void 0 : _b.trim()) || "http";
  const host = (_c = getRequestHeader(event, "host")) != null ? _c : "";
  const home = host ? `${proto}://${host}/` : "/";
  const target = `${megrezConfig().base}/logout?next=${encodeURIComponent(home)}`;
  return sendRedirect(event, target, 302);
});

export { logout as default };
//# sourceMappingURL=logout.mjs.map
