import { c as defineEventHandler, aJ as FIELD_SCOPES, g as getQuery, aK as listFieldDefs } from '../../_/nitro.mjs';
import { z } from 'zod';
import { g as guarded } from '../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const query = z.object({
  scope: z.enum(FIELD_SCOPES).optional(),
  status: z.enum(["active", "proposed", "dismissed"]).optional()
});
const fields = defineEventHandler(
  (event) => guarded(async () => {
    const parsed = query.parse(getQuery(event));
    return { fields: await listFieldDefs(parsed) };
  })
);

export { fields as default };
//# sourceMappingURL=fields.mjs.map
