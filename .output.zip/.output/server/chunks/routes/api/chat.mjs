import { C as CONFIG, N as crmTools, O as agentModel, P as AgentDisabledError, Q as contactContext, S as CHAT_SYSTEM, T as contactPreamble, U as companyContext, V as companyPreamble, W as dealContext, X as dealPreamble, c as defineEventHandler, Y as chatInput, r as readBody, Z as agentCapability, _ as setResponseHeaders } from '../../_/nitro.mjs';
import { streamText, stepCountIs } from 'ai';
import { g as getConversation, c as createConversation, a as appendMessage, b as conversationMessages } from '../../_/chat.mjs';
import { g as guarded } from '../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'zod';
import '@ai-sdk/openai-compatible';
import 'node:url';

function titleFrom(message) {
  const trimmed = message.trim().replace(/\s+/g, " ");
  return trimmed.length > 30 ? `${trimmed.slice(0, 30)}\u2026` : trimmed;
}
async function resolveConversation(input) {
  if (input.conversationId) {
    const existing = await getConversation(input.conversationId);
    if (existing) return existing;
  }
  return createConversation({
    contactId: input.focus.contactId,
    companyId: input.focus.companyId,
    dealId: input.focus.dealId,
    title: titleFrom(input.message)
  });
}
async function systemPromptFor(focus) {
  if (focus.contactId) {
    const context = await contactContext(focus.contactId);
    if (context) {
      return [CHAT_SYSTEM, contactPreamble(context)].join("\n\n");
    }
  }
  if (focus.companyId) {
    const context = await companyContext(focus.companyId);
    if (context) {
      return [CHAT_SYSTEM, companyPreamble(context)].join("\n\n");
    }
  }
  if (focus.dealId) {
    const context = await dealContext(focus.dealId);
    if (context) {
      return [CHAT_SYSTEM, dealPreamble(context)].join("\n\n");
    }
  }
  return CHAT_SYSTEM;
}
async function* chatStream(input) {
  var _a, _b, _c;
  yield { type: "start", conversationId: input.conversationId };
  await appendMessage({
    conversationId: input.conversationId,
    role: "user",
    content: input.message
  });
  const stored = await conversationMessages(input.conversationId, CONFIG.agent.historyMessages);
  const history = stored.filter((message) => {
    var _a2;
    return ((_a2 = message.content) != null ? _a2 : "").trim().length > 0;
  }).map((message) => {
    var _a2;
    return {
      role: message.role === "user" ? "user" : "assistant",
      content: (_a2 = message.content) != null ? _a2 : ""
    };
  });
  let text = "";
  let reasoning = "";
  const toolCalls = [];
  let tokens = null;
  try {
    const system = (_a = input.systemOverride) != null ? _a : await systemPromptFor(input.focus);
    const result = streamText({
      model: agentModel(),
      system,
      messages: history,
      tools: crmTools(),
      stopWhen: stepCountIs(CONFIG.agent.maxSteps),
      maxOutputTokens: CONFIG.agent.maxOutputTokens,
      maxRetries: CONFIG.agent.maxRetries
    });
    for await (const part of result.fullStream) {
      switch (part.type) {
        case "reasoning-delta": {
          reasoning += part.text;
          yield { type: "reasoning", text: part.text };
          break;
        }
        case "text-delta": {
          text += part.text;
          yield { type: "text", text: part.text };
          break;
        }
        case "tool-call": {
          toolCalls.push({ name: part.toolName, input: part.input, result: null });
          yield { type: "tool", name: part.toolName, input: part.input };
          break;
        }
        case "tool-result": {
          const call = toolCalls.find(
            (item) => item.name === part.toolName && item.result === null
          );
          if (call) call.result = part.output;
          yield { type: "tool_result", name: part.toolName, result: part.output };
          break;
        }
        case "finish": {
          tokens = (_c = (_b = part.totalUsage) == null ? void 0 : _b.totalTokens) != null ? _c : null;
          break;
        }
        case "error": {
          yield { type: "error", message: describeError(part.error) };
          break;
        }
        default:
          break;
      }
    }
  } catch (error) {
    yield { type: "error", message: describeError(error) };
    if (error instanceof AgentDisabledError) {
      yield { type: "done", conversationId: input.conversationId, messageId: "", tokens: null };
      return;
    }
  }
  const assistant = await appendMessage({
    conversationId: input.conversationId,
    role: "assistant",
    content: text,
    reasoning,
    toolCalls
  });
  yield {
    type: "done",
    conversationId: input.conversationId,
    messageId: assistant.id,
    tokens
  };
}
function describeError(error) {
  if (error instanceof AgentDisabledError) return error.message;
  if (error instanceof Error) return `\u667A\u80FD\u4F53\u8C03\u7528\u5931\u8D25\uFF1A${error.message}`;
  return "\u667A\u80FD\u4F53\u8C03\u7528\u5931\u8D25\uFF1A\u672A\u77E5\u9519\u8BEF\u3002";
}

const chat = defineEventHandler(
  (event) => guarded(async () => {
    var _a, _b, _c, _d;
    const input = chatInput.parse(await readBody(event));
    const focus = {
      contactId: (_a = input.contactId) != null ? _a : null,
      companyId: (_b = input.companyId) != null ? _b : null,
      dealId: (_c = input.dealId) != null ? _c : null
    };
    if (!agentCapability().enabled) {
      return {
        disabled: true,
        reason: agentCapability().reason
      };
    }
    const conversation = await resolveConversation({
      conversationId: (_d = input.conversationId) != null ? _d : null,
      focus,
      message: input.message
    });
    const encoder = new TextEncoder();
    const body = new ReadableStream({
      async start(controller) {
        const send = (payload) => {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(payload)}

`));
        };
        try {
          for await (const chunk of chatStream({
            conversationId: conversation.id,
            focus,
            message: input.message
          })) {
            send(chunk);
          }
        } catch (error) {
          send({ type: "error", message: describeError(error) });
        } finally {
          controller.close();
        }
      }
    });
    setResponseHeaders(event, {
      "content-type": "text/event-stream; charset=utf-8",
      "cache-control": "no-cache, no-transform",
      connection: "keep-alive"
    });
    return body;
  })
);

export { chat as default };
//# sourceMappingURL=chat.mjs.map
