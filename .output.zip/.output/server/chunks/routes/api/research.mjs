import { c as defineEventHandler, r as readBody, Z as agentCapability, aS as getContact, af as enqueueResearch, aW as getCompany, a6 as enqueueCompanyResearch } from '../../_/nitro.mjs';
import { z } from 'zod';
import { g as guarded, b as badRequest, n as notFound } from '../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const body = z.object({
  subject: z.enum(["contact", "company"]),
  id: z.string().trim().min(1).max(36)
});
const research = defineEventHandler(
  (event) => guarded(async () => {
    const input = body.parse(await readBody(event));
    const capability = agentCapability();
    if (!capability.enabled) throw badRequest(capability.reason);
    if (input.subject === "contact") {
      const contact = await getContact(input.id);
      if (!contact) throw notFound("\u8054\u7CFB\u4EBA\u4E0D\u5B58\u5728\u3002");
      const taskId2 = await enqueueResearch(input.id, "\u624B\u52A8\u70B9\u300C\u91CD\u65B0\u7814\u7A76\u300D\u3002");
      return { queued: true, taskId: taskId2 };
    }
    const company = await getCompany(input.id);
    if (!company) throw notFound("\u516C\u53F8\u4E0D\u5B58\u5728\u3002");
    const taskId = await enqueueCompanyResearch(input.id, "\u624B\u52A8\u70B9\u300C\u91CD\u65B0\u7814\u7A76\u300D\u3002");
    return { queued: true, taskId };
  })
);

export { research as default };
//# sourceMappingURL=research.mjs.map
