import { c as defineEventHandler, a0 as companyInput, r as readBody, a5 as createCompany, Z as agentCapability, a6 as enqueueCompanyResearch, a7 as listCompanies, l as listQuery, g as getQuery } from '../../_/nitro.mjs';
import { g as guarded } from '../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'zod';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const index = defineEventHandler(
  (event) => guarded(async () => {
    if (event.method === "POST") {
      const input = companyInput.parse(await readBody(event));
      const company = await createCompany(input);
      if (agentCapability().enabled) {
        await enqueueCompanyResearch(company.id, "\u65B0\u5EFA\u516C\u53F8\uFF0C\u81EA\u52A8\u89E6\u53D1\u4E00\u6B21\u540E\u53F0\u7814\u7A76\u3002");
      }
      return { company };
    }
    return listCompanies(listQuery.parse(getQuery(event)));
  })
);

export { index as default };
//# sourceMappingURL=index.mjs.map
