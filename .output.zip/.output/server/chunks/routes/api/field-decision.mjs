import { c as defineEventHandler, r as readBody, aG as dismissFieldDef, aH as acceptFieldDef, aI as recordCompanyFact, G as recordFact } from '../../_/nitro.mjs';
import { z } from 'zod';
import { g as guarded, n as notFound } from '../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const body = z.object({
  id: z.string().trim().min(1).max(36),
  action: z.enum(["accept", "reject"])
});
const fieldDecision = defineEventHandler(
  (event) => guarded(async () => {
    const input = body.parse(await readBody(event));
    if (input.action === "reject") {
      const rejected = await dismissFieldDef(input.id);
      if (!rejected.ok) throw notFound(rejected.reason);
      return { ok: true, reason: rejected.reason };
    }
    const accepted = await acceptFieldDef(input.id);
    if (!accepted.ok || !accepted.def) throw notFound(accepted.reason);
    const def = accepted.def;
    if (!def.sampleValue || !def.sampleRef || !def.evidence || def.evidence.length === 0) {
      return { ok: true, reason: "\u5B57\u6BB5\u5DF2\u751F\u6548\u3002", valueWritten: false };
    }
    const written = def.scope === "company" ? await recordCompanyFact({
      companyId: def.sampleRef,
      field: def.key,
      value: def.sampleValue,
      evidence: def.evidence,
      source: "human"
    }) : await recordFact({
      contactId: def.sampleRef,
      field: def.key,
      value: def.sampleValue,
      evidence: def.evidence,
      source: "human"
    });
    return {
      ok: true,
      reason: written.stored ? "\u5B57\u6BB5\u5DF2\u751F\u6548\uFF0C\u793A\u4F8B\u503C\u5DF2\u5199\u5165\u3002" : `\u5B57\u6BB5\u5DF2\u751F\u6548\u3002${written.reason}`,
      valueWritten: written.stored
    };
  })
);

export { fieldDecision as default };
//# sourceMappingURL=field-decision.mjs.map
