import { aM as findContactByName, aN as archiveOriginals, aO as diffArchiveMessages, aP as digestIntakeText, C as CONFIG, aQ as WECHAT_SYSTEM, N as crmTools, O as agentModel, aR as intakeTitle, P as AgentDisabledError, aS as getContact, f as createActivity, c as defineEventHandler, D as createError, r as readBody, Z as agentCapability } from '../../_/nitro.mjs';
import { z } from 'zod';
import { c as createConversation, a as appendMessage, d as attachConversation, b as conversationMessages } from '../../_/chat.mjs';
import { generateText, stepCountIs } from 'ai';
import { g as guarded } from '../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import '@ai-sdk/openai-compatible';
import 'node:url';

function pickContactId(toolCalls) {
  var _a, _b, _c;
  const created = [];
  const matched = [];
  const written = [];
  for (const call of toolCalls) {
    const input = call.input;
    const payload = call.result;
    if (call.name === "ensure_contact") {
      const id = payload && typeof payload.id === "string" ? payload.id : null;
      if (!id) continue;
      ((payload == null ? void 0 : payload.created) === true ? created : matched).push(id);
      continue;
    }
    const succeeded = payload !== null && typeof payload === "object" && (payload.stored === true || payload.created === true || Boolean(payload.activity));
    const contactId = input && typeof input.contact_id === "string" ? input.contact_id : null;
    if (succeeded && contactId) written.push(contactId);
  }
  return (_c = (_b = (_a = created[0]) != null ? _a : matched[0]) != null ? _b : written[0]) != null ? _c : null;
}
function describeError(error) {
  if (error instanceof AgentDisabledError) return error.message;
  if (error instanceof Error) return `\u667A\u80FD\u4F53\u8C03\u7528\u5931\u8D25\uFF1A${error.message}`;
  return "\u667A\u80FD\u4F53\u8C03\u7528\u5931\u8D25\uFF1A\u672A\u77E5\u9519\u8BEF\u3002";
}
function buildIntakeMessage(input, bodyText = input.text, incrementalNote) {
  var _a;
  const file = ((_a = input.file) == null ? void 0 : _a.trim()) || "\uFF08\u672A\u63D0\u4F9B\u6587\u4EF6\u540D\uFF09";
  const header = `\u3010\u5FAE\u4FE1\u804A\u5929\u8BB0\u5F55\u3011\u5BF9\u65B9\u6635\u79F0\uFF1A${input.person}\uFF1B\u6765\u6E90\u6587\u4EF6\uFF1A${file}`;
  const note = incrementalNote ? `
\uFF08${incrementalNote}\uFF09` : "";
  const trailer = `\u4EE5\u4E0A\u4E3A\u8BE5\u4F1A\u8BDD\u7684\u5168\u90E8\u804A\u5929\u539F\u6587\uFF0C\u672A\u505A\u4EFB\u4F55\u52A0\u5DE5\u3002\u8BF7\u6309\u89C4\u5219\u62BD\u53D6\u8054\u7CFB\u4EBA\u4E0E\u516C\u53F8\u4FE1\u606F\u5E76\u5199\u5165 CRM\u3002`;
  return [header, "---", bodyText.trim(), "---", trailer + note].join("\n");
}
async function runIntake(input) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i;
  const knownContact = await findContactByName(input.person);
  const storedOriginals = knownContact ? await archiveOriginals(knownContact.id, 3) : [];
  const diff = diffArchiveMessages(input.text, storedOriginals);
  const incrementalNote = diff.isIncremental ? `\u589E\u91CF\u5BFC\u5165\uFF1A\u8BE5\u4F1A\u8BDD\u5DF2\u5165\u5E93 ${diff.storedCount} \u6761\u5386\u53F2\u6D88\u606F\uFF08\u4E0D\u91CD\u8FF0\uFF09\uFF1B\u672C\u6B21\u65B0\u589E ${diff.newCount} \u6761\uFF0C\u8BF7\u53EA\u57FA\u4E8E\u65B0\u589E\u5185\u5BB9\u505A\u589E\u91CF\u5206\u6790\u3002` : void 0;
  const message = buildIntakeMessage(input, diff.isIncremental ? diff.newBody : input.text, incrementalNote);
  const conversation = await createConversation({
    contactId: null,
    companyId: null,
    dealId: null,
    title: `\u5FAE\u4FE1\u8BB0\u5F55\u5BFC\u5165\uFF1A${input.person}`.slice(0, 30)
  });
  await appendMessage({
    conversationId: conversation.id,
    role: "user",
    content: message
  });
  if (diff.isIncremental && diff.newCount === 0) {
    const digest2 = digestIntakeText(input.text);
    const contact2 = knownContact;
    await attachConversation({
      conversationId: conversation.id,
      contactId: (_a = contact2 == null ? void 0 : contact2.id) != null ? _a : null,
      companyId: (_b = contact2 == null ? void 0 : contact2.companyId) != null ? _b : null,
      title: intakeTitle(input.person, digest2)
    });
    const summary2 = `\u672C\u6BB5\u65E0\u65B0\u589E\uFF1A${diff.incomingCount} \u6761\u6D88\u606F\u5168\u90E8\u5DF2\u5165\u5E93\uFF08\u7559\u5E95 ${diff.storedCount} \u6761\uFF09\uFF0C\u672A\u8C03\u7528\u6A21\u578B\u3002`;
    return {
      conversationId: conversation.id,
      messageId: "",
      contactId: (_c = contact2 == null ? void 0 : contact2.id) != null ? _c : null,
      summary: summary2,
      toolCalls: [],
      counts: {},
      created: { contacts: [], companies: [] },
      tokens: null
    };
  }
  const stored = await conversationMessages(conversation.id, CONFIG.agent.historyMessages);
  const history = stored.filter((item) => {
    var _a2;
    return ((_a2 = item.content) != null ? _a2 : "").trim().length > 0;
  }).map((item) => {
    var _a2;
    return {
      role: item.role === "user" ? "user" : "assistant",
      content: (_a2 = item.content) != null ? _a2 : ""
    };
  });
  const result = await generateText({
    model: agentModel(),
    system: WECHAT_SYSTEM,
    messages: history,
    tools: crmTools(),
    stopWhen: stepCountIs(CONFIG.agent.maxSteps),
    maxOutputTokens: CONFIG.agent.maxOutputTokens,
    maxRetries: CONFIG.agent.maxRetries
  });
  const toolCalls = result.steps.flatMap((step) => {
    var _a2;
    return (_a2 = step.toolCalls) != null ? _a2 : [];
  }).map((call) => ({ name: call.toolName, input: call.input, result: null }));
  const outputs = result.steps.flatMap((step) => {
    var _a2;
    return (_a2 = step.toolResults) != null ? _a2 : [];
  });
  for (const output of outputs) {
    const target = toolCalls.find((call) => call.name === output.toolName && call.result === null);
    if (target) target.result = output.output;
  }
  const counts = {};
  for (const call of toolCalls) {
    counts[call.name] = ((_d = counts[call.name]) != null ? _d : 0) + 1;
  }
  const created = { contacts: [], companies: [] };
  for (const call of toolCalls) {
    const payload = call.result;
    if (!payload || payload.created !== true) continue;
    if (call.name === "ensure_contact") {
      created.contacts.push({ id: String(payload.id), name: String(payload.name) });
    }
    if (call.name === "ensure_company") {
      created.companies.push({ id: String(payload.id), name: String(payload.name) });
    }
  }
  const summary = result.text.trim();
  if (!summary && toolCalls.length === 0) {
    throw new Error(
      `\u667A\u80FD\u4F53\u672C\u8F6E\u6CA1\u6709\u4EA7\u751F\u4EFB\u4F55\u8F93\u51FA\uFF08finishReason=${result.finishReason}\uFF09\u3002\u5DF2\u6D88\u8017\u8F93\u51FA token ${(_f = (_e = result.totalUsage) == null ? void 0 : _e.outputTokens) != null ? _f : 0}\uFF0C\u8BF7\u68C0\u67E5 CONFIG.agent.maxOutputTokens \u662F\u5426\u8FC7\u5C0F\uFF0C\u6216\u6A21\u578B\u670D\u52A1\u662F\u5426\u5F02\u5E38\u3002`
    );
  }
  const assistant = await appendMessage({
    conversationId: conversation.id,
    role: "assistant",
    content: summary,
    reasoning: "",
    toolCalls: toolCalls.map(
      (call) => ({ name: call.name, input: call.input, result: call.result })
    )
  });
  const digest = digestIntakeText(input.text);
  const title = intakeTitle(input.person, digest);
  const contactId = pickContactId(toolCalls);
  const contact = contactId ? await getContact(contactId) : null;
  const companyId = (_g = contact == null ? void 0 : contact.companyId) != null ? _g : null;
  await attachConversation({ conversationId: conversation.id, contactId, companyId, title });
  if (contactId) {
    await createActivity({
      kind: "chat_log",
      title,
      body: summary || null,
      contactId,
      companyId,
      dealId: null,
      dueAt: null
    });
  }
  return {
    conversationId: conversation.id,
    messageId: assistant.id,
    contactId,
    summary,
    toolCalls,
    counts,
    created,
    tokens: (_i = (_h = result.totalUsage) == null ? void 0 : _h.totalTokens) != null ? _i : null
  };
}

const intakeInput = z.object({
  person: z.string().trim().min(1, "\u7F3A\u5C11\u4F1A\u8BDD\u6635\u79F0").max(64),
  file: z.string().trim().max(CONFIG.text.maxFieldLength).nullish(),
  text: z.string().trim().min(1, "\u804A\u5929\u8BB0\u5F55\u4E0D\u80FD\u4E3A\u7A7A").max(CONFIG.intake.maxTextLength)
});
const intake = defineEventHandler(
  (event) => guarded(async () => {
    var _a;
    if (event.method !== "POST") {
      throw createError({ statusCode: 405, statusMessage: "\u8BE5\u7AEF\u70B9\u53EA\u63A5\u53D7 POST \u8BF7\u6C42\u3002" });
    }
    const input = intakeInput.parse(await readBody(event));
    const capability = agentCapability();
    if (!capability.enabled) {
      return {
        ok: false,
        disabled: true,
        reason: capability.reason
      };
    }
    try {
      const result = await runIntake({
        person: input.person,
        file: (_a = input.file) != null ? _a : null,
        text: input.text
      });
      return { ok: true, ...result };
    } catch (error) {
      return {
        ok: false,
        reason: describeError(error)
      };
    }
  })
);

export { intake as default };
//# sourceMappingURL=intake.mjs.map
