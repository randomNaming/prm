import { ai as openDeals, aj as overdueTasks, ak as recentActivities, al as contactCompany, C as CONFIG, c as defineEventHandler } from '../../_/nitro.mjs';
import { g as guarded } from '../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'zod';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

async function dashboard$1(now = Date.now()) {
  const [deals, tasks, activities] = await Promise.all([
    openDeals(CONFIG.lists.pageSize),
    overdueTasks(now, CONFIG.lists.pageSize),
    recentActivities(CONFIG.lists.recentActivityLimit)
  ]);
  const dealRows = await Promise.all(
    deals.map(async (deal) => {
      var _a;
      const company = await contactCompany(deal.companyId);
      return {
        id: deal.id,
        name: deal.name,
        stage: deal.stage,
        companyName: (_a = company == null ? void 0 : company.name) != null ? _a : null,
        stageChangedAt: deal.stageChangedAt,
        expectedCloseDate: deal.expectedCloseDate
      };
    })
  );
  const taskRows = tasks;
  return { deals: dealRows, tasks: taskRows, activities };
}

const dashboard = defineEventHandler(() => guarded(async () => dashboard$1()));

export { dashboard as default };
//# sourceMappingURL=dashboard.mjs.map
