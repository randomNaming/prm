import { c as defineEventHandler, r as readBody, i as completeActivity, j as reopenActivity } from '../../_/nitro.mjs';
import { z } from 'zod';
import { g as guarded, n as notFound } from '../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const body = z.object({
  id: z.string().trim().min(1).max(36),
  action: z.enum(["complete", "reopen"])
});
const activityDecision = defineEventHandler(
  (event) => guarded(async () => {
    const input = body.parse(await readBody(event));
    const ok = input.action === "complete" ? await completeActivity(input.id) : await reopenActivity(input.id);
    if (!ok) throw notFound("\u4EFB\u52A1\u4E0D\u5B58\u5728\u6216\u5DF2\u7ECF\u5904\u7406\u8FC7\u4E86\u3002");
    return { ok: true, action: input.action };
  })
);

export { activityDecision as default };
//# sourceMappingURL=activity-decision.mjs.map
