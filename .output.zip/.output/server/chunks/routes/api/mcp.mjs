import { I as env, c as defineEventHandler } from '../../_/nitro.mjs';
import { g as guarded } from '../../_/guard.mjs';
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { parse } from 'dotenv';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'zod';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const ROOT = process.cwd();
function readEnvFile(path) {
  if (!existsSync(path)) return {};
  try {
    return parse(readFileSync(path, "utf8"));
  } catch {
    return {};
  }
}
function envItem(fileEnv, input) {
  var _a, _b;
  const { fallback, ...meta } = input;
  const fromProcess = (_a = process.env[input.key]) == null ? void 0 : _a.trim();
  const fromFile = (_b = fileEnv[input.key]) == null ? void 0 : _b.trim();
  if (fromProcess) {
    return { ...meta, value: fromProcess, source: "env" };
  }
  if (fromFile) {
    return { ...meta, value: fromFile, source: "file" };
  }
  return { ...meta, value: fallback != null ? fallback : "", source: "missing" };
}
function stdioSnippet(input) {
  return JSON.stringify(
    {
      mcpServers: {
        [input.id]: {
          command: "node",
          args: [input.entry],
          env: input.env
        }
      }
    },
    null,
    2
  );
}
function httpSnippet(id, port) {
  return JSON.stringify(
    { mcpServers: { [id]: { type: "http", url: `http://127.0.0.1:${port}/mcp` } } },
    null,
    2
  );
}
const STDIO_WHERE = "\u901A\u7528 mcpServers \u7ED3\u6784\uFF1ACursor \u7684 .cursor/mcp.json\uFF08\u6216 ~/.cursor/mcp.json\uFF09\u3001WorkBuddy \u7684\u8FDE\u63A5\u5668\u914D\u7F6E\u3001Claude Desktop \u7684 %APPDATA%\\Claude\\claude_desktop_config.json \u90FD\u586B\u8FD9\u4E00\u6BB5\u3002";
function platformBaseUrl() {
  const current = env();
  const reachable = current.host === "0.0.0.0" || current.host === "::" || current.host === "" ? "127.0.0.1" : current.host;
  return `http://${reachable}:${current.port}`;
}
function crmServer() {
  const packageDir = resolve(ROOT, "mcp-crm");
  const entry = resolve(packageDir, "dist", "index.js");
  const envFile = resolve(packageDir, ".env");
  const fileEnv = readEnvFile(envFile);
  const baseUrl = platformBaseUrl();
  const crmBaseUrl = envItem(fileEnv, {
    key: "CRM_BASE_URL",
    required: true,
    description: "CRM \u5E73\u53F0\u5730\u5740\uFF0C\u6B63\u5E38\u60C5\u51B5\u4E0B\u5C31\u662F\u672C\u5E73\u53F0\u3002",
    fallback: baseUrl
  });
  const maxText = envItem(fileEnv, {
    key: "CRM_MAX_TEXT_LENGTH",
    required: false,
    description: "\u5355\u6B21\u8F6C\u53D1\u7684\u804A\u5929\u8BB0\u5F55\u5B57\u7B26\u4E0A\u9650\uFF0C\u9ED8\u8BA4 50000\uFF0C\u8D85\u9650\u4F1A\u88AB\u62D2\u7EDD\u5E76\u8981\u6C42\u5206\u6279\u3002"
  });
  const httpPort = envItem(fileEnv, {
    key: "MCP_HTTP_PORT",
    required: false,
    description: "\u7559\u7A7A = \u53EA\u7528 stdio\uFF08\u63A8\u8350\uFF09\u3002\u586B\u7AEF\u53E3\u540E\u6539\u4E3A Streamable HTTP\uFF0C\u53EA\u7ED1\u5B9A 127.0.0.1\u3002"
  });
  const entryExists = existsSync(entry);
  const blockers = [];
  if (!existsSync(packageDir)) blockers.push("\u6CA1\u6709\u627E\u5230 mcp-crm \u76EE\u5F55\uFF0C\u786E\u8BA4\u5B83\u4E0E\u5E73\u53F0\u5728\u540C\u4E00\u5C42\u76EE\u5F55\u4E0B\u3002");
  if (!entryExists) blockers.push("\u5C1A\u672A\u7F16\u8BD1\uFF1A\u5148\u5728\u8BE5\u76EE\u5F55\u6267\u884C bun install \u4E0E bun run build\uFF0C\u4EA7\u51FA dist/index.js\u3002");
  if (crmBaseUrl.source === "missing") blockers.push("\u672A\u914D\u7F6E CRM_BASE_URL\uFF0C\u670D\u52A1\u542F\u52A8\u4F1A\u76F4\u63A5\u4EE5\u975E\u96F6\u7801\u9000\u51FA\u3002");
  const port = httpPort.source === "missing" ? "3940" : httpPort.value;
  const effectiveBaseUrl = crmBaseUrl.source === "missing" ? baseUrl : crmBaseUrl.value;
  return {
    id: "crm",
    name: "mcp-crm",
    direction: "\u5199",
    summary: "\u5BA2\u6237\u7AEF\u628A\u804A\u5929\u8BB0\u5F55\u539F\u6587\u4EA4\u7ED9\u5E73\u53F0\uFF1A\u8C03 import_wechat_chat \u8F6C\u53D1\u5230 /api/intake\uFF0C\u7531\u5E73\u53F0\u4FA7\u667A\u80FD\u4F53\u62BD\u53D6\u8054\u7CFB\u4EBA\u3001\u516C\u53F8\u4E0E\u5B57\u6BB5\u5E76\u5EFA\u6863\u3002\u672C\u5305\u4E0D\u89E3\u6790\u3001\u4E0D\u6539\u5199\u3001\u4E0D\u843D\u76D8\u3002",
    packageDir,
    entry,
    entryExists,
    envFile,
    envFileExists: existsSync(envFile),
    env: [crmBaseUrl, maxText, httpPort],
    tools: [
      { name: "import_wechat_chat", summary: "\u628A\u4E00\u6BB5\u804A\u5929\u8BB0\u5F55\u539F\u6837\u8F6C\u53D1\u7ED9\u5E73\u53F0\uFF0C\u8FD4\u56DE\u65B0\u5EFA\u7684\u8054\u7CFB\u4EBA\u4E0E\u516C\u53F8\u3002" },
      { name: "intake_status", summary: "\u63A2\u6D4B\u5E73\u53F0\u662F\u5426\u5728\u7EBF\u3001\u667A\u80FD\u4F53\u662F\u5426\u53EF\u7528\u3002\u5199\u5165\u5931\u8D25\u524D\u5148\u8C03\u5B83\u5B9A\u4F4D\u95EE\u9898\u3002" }
    ],
    snippets: [
      {
        label: "stdio \u6A21\u5F0F\uFF08\u63A8\u8350\uFF09",
        where: STDIO_WHERE,
        json: stdioSnippet({
          id: "crm",
          entry,
          env: { CRM_BASE_URL: effectiveBaseUrl }
        })
      },
      {
        label: `Streamable HTTP \u6A21\u5F0F\uFF08\u5148\u7528 MCP_HTTP_PORT=${port} node dist/index.js \u8D77\u670D\u52A1\uFF09`,
        where: "\u5BA2\u6237\u7AEF\u53EA\u652F\u6301\u8FDC\u7A0B\u8FDE\u63A5\u65F6\u7528\u8FD9\u4E00\u6BB5\uFF1B\u670D\u52A1\u53EA\u76D1\u542C 127.0.0.1\u3002",
        json: httpSnippet("crm", port)
      }
    ],
    buildCommands: [
      `cd "${packageDir}"`,
      "bun install",
      "bun run build"
    ],
    blockers,
    ready: blockers.length === 0
  };
}
function mcpOverview() {
  return {
    platformBaseUrl: platformBaseUrl(),
    root: ROOT,
    servers: [crmServer()],
    notes: [
      "mcp-crm \u662F\u5199\u4FA7\uFF1A\u5BA2\u6237\u7AEF\u628A\u804A\u5929\u8BB0\u5F55\u4EA4\u7ED9\u5E73\u53F0\uFF0C\u7531\u667A\u80FD\u4F53\u62BD\u53D6\u8054\u7CFB\u4EBA\u3001\u516C\u53F8\u4E0E\u5B57\u6BB5\u5E76\u5EFA\u6863\u3002",
      "\u9ED8\u8BA4 stdio \u4F20\u8F93\uFF0C\u65E0\u9700\u5F00\u653E\u7AEF\u53E3\uFF1B\u53EA\u6709\u8FDC\u7A0B\u5BA2\u6237\u7AEF\u63A5\u5165\u65F6\u624D\u7528 Streamable HTTP\u3002",
      "\u5E73\u53F0\u4FA7\u5199\u5165\u540C\u65F6\u63D0\u4F9B HTTP \u5165\u53E3 POST /api/intake\uFF0C\u4F9B\u4E0D\u65B9\u4FBF\u88C5 MCP \u5BA2\u6237\u7AEF\u7684\u573A\u666F\u76F4\u8FDE\u3002",
      "HTTP \u6A21\u5F0F\u53EA\u7ED1\u5B9A 127.0.0.1\u3002\u8981\u5BF9\u516C\u7F51\u66B4\u9732\u5FC5\u987B\u5148\u524D\u7F6E\u53CD\u5411\u4EE3\u7406\u5E76\u52A0\u8BA4\u8BC1\u3002"
    ]
  };
}

const mcp = defineEventHandler(
  () => guarded(async () => {
    return mcpOverview();
  })
);

export { mcp as default };
//# sourceMappingURL=mcp.mjs.map
