import { c as defineEventHandler, l as listQuery, e as activityInput, r as readBody, R as READONLY_ACTIVITY_KINDS, f as createActivity, g as getQuery, h as listActivities } from '../../_/nitro.mjs';
import { z } from 'zod';
import { g as guarded, b as badRequest } from '../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const query = listQuery.extend({
  contactId: z.string().trim().max(36).optional(),
  companyId: z.string().trim().max(36).optional(),
  dealId: z.string().trim().max(36).optional()
});
const activities = defineEventHandler(
  (event) => guarded(async () => {
    var _a, _b, _c;
    if (event.method === "POST") {
      const input = activityInput.parse(await readBody(event));
      if (READONLY_ACTIVITY_KINDS.includes(input.kind)) {
        throw badRequest(`\u300C${input.kind}\u300D\u7C7B\u578B\u7684\u6D3B\u52A8\u7531\u7CFB\u7EDF\u5199\u5165\uFF0C\u4E0D\u80FD\u624B\u5DE5\u521B\u5EFA\u3002`);
      }
      return { activity: await createActivity(input) };
    }
    const parsed = query.parse(getQuery(event));
    return listActivities({
      contactId: (_a = parsed.contactId) != null ? _a : null,
      companyId: (_b = parsed.companyId) != null ? _b : null,
      dealId: (_c = parsed.dealId) != null ? _c : null,
      limit: parsed.pageSize,
      page: parsed.page
    });
  })
);

export { activities as default };
//# sourceMappingURL=activities.mjs.map
