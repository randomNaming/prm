import { c as defineEventHandler, $ as getRouterParam, a9 as contactDetail, aa as contactInput, r as readBody, ab as updateContact, ac as archiveContact } from '../../../_/nitro.mjs';
import { g as guarded, n as notFound } from '../../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'zod';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const _id_ = defineEventHandler(
  (event) => guarded(async () => {
    const id = getRouterParam(event, "id");
    if (!id) throw notFound("\u8054\u7CFB\u4EBA\u4E0D\u5B58\u5728\u3002");
    if (event.method === "GET") {
      const detail = await contactDetail(id);
      if (!detail) throw notFound("\u8054\u7CFB\u4EBA\u4E0D\u5B58\u5728\u3002");
      return detail;
    }
    if (event.method === "PUT") {
      const input = contactInput.parse(await readBody(event));
      const contact = await updateContact(id, input);
      if (!contact) throw notFound("\u8054\u7CFB\u4EBA\u4E0D\u5B58\u5728\u3002");
      return { contact };
    }
    const archived = await archiveContact(id);
    if (!archived) throw notFound("\u8054\u7CFB\u4EBA\u4E0D\u5B58\u5728\u6216\u5DF2\u5F52\u6863\u3002");
    return { archived: true };
  })
);

export { _id_ as default };
//# sourceMappingURL=_id_.mjs.map
