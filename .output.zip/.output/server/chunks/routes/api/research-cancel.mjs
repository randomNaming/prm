import { c as defineEventHandler, r as readBody, aV as cancelAgentTasks } from '../../_/nitro.mjs';
import { z } from 'zod';
import { g as guarded } from '../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const body = z.object({
  subject: z.enum(["contact", "company"]),
  id: z.string().trim().min(1).max(36)
});
const researchCancel = defineEventHandler(
  (event) => guarded(async () => {
    const input = body.parse(await readBody(event));
    const cancelled = await cancelAgentTasks({
      targetType: input.subject,
      targetId: input.id
    });
    return {
      ok: true,
      cancelled,
      reason: cancelled > 0 ? `\u5DF2\u7EC8\u6B62 ${cancelled} \u9879\u540E\u53F0\u4EFB\u52A1\u3002` : "\u6CA1\u6709\u627E\u5230\u8FDB\u884C\u4E2D\u7684\u540E\u53F0\u4EFB\u52A1\uFF08\u53EF\u80FD\u521A\u521A\u81EA\u5DF1\u8DD1\u5B8C\u4E86\uFF09\u3002"
    };
  })
);

export { researchCancel as default };
//# sourceMappingURL=research-cancel.mjs.map
