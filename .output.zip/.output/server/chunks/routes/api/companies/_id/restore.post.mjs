import { c as defineEventHandler, $ as getRouterParam, a4 as restoreCompany } from '../../../../_/nitro.mjs';
import { g as guarded, n as notFound } from '../../../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'zod';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const restore_post = defineEventHandler(
  (event) => guarded(async () => {
    const id = getRouterParam(event, "id");
    if (!id) throw notFound("\u516C\u53F8\u4E0D\u5B58\u5728\u3002");
    const restored = await restoreCompany(id);
    if (!restored) throw notFound("\u516C\u53F8\u4E0D\u5B58\u5728\u3002");
    return { restored: true };
  })
);

export { restore_post as default };
//# sourceMappingURL=restore.post.mjs.map
