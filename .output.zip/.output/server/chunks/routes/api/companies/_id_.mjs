import { c as defineEventHandler, $ as getRouterParam, a0 as companyInput, r as readBody, a1 as updateCompany, a2 as archiveCompany, a3 as companyDetail } from '../../../_/nitro.mjs';
import { g as guarded, n as notFound } from '../../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'zod';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const _id_ = defineEventHandler(
  (event) => guarded(async () => {
    const id = getRouterParam(event, "id");
    if (!id) throw notFound("\u516C\u53F8\u4E0D\u5B58\u5728\u3002");
    if (event.method === "PUT") {
      const input = companyInput.parse(await readBody(event));
      const company = await updateCompany(id, input);
      if (!company) throw notFound("\u516C\u53F8\u4E0D\u5B58\u5728\u3002");
      return { company };
    }
    if (event.method === "DELETE") {
      const archived = await archiveCompany(id);
      if (!archived) throw notFound("\u516C\u53F8\u4E0D\u5B58\u5728\u6216\u5DF2\u5F52\u6863\u3002");
      return { archived: true };
    }
    const detail = await companyDetail(id);
    if (!detail) throw notFound("\u516C\u53F8\u4E0D\u5B58\u5728\u3002");
    return detail;
  })
);

export { _id_ as default };
//# sourceMappingURL=_id_.mjs.map
