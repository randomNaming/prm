import { c as defineEventHandler, B as BOARD_QUADRANTS, k as BOARD_ITEM_TYPES, r as readBody } from '../../../_/nitro.mjs';
import { z } from 'zod';
import { p as pinItem } from '../../../_/board.mjs';
import { g as guarded, b as badRequest } from '../../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const pinInput = z.object({
  type: z.enum(BOARD_ITEM_TYPES),
  id: z.string().trim().min(1).max(36),
  quadrant: z.enum(BOARD_QUADRANTS),
  /** 客户端把「系统推断值」一并回传：拖回原位即等于恢复自动，不用再做一个重置按钮。 */
  inferred: z.enum(BOARD_QUADRANTS)
});
const pin_post = defineEventHandler(
  (event) => guarded(async () => {
    const input = pinInput.parse(await readBody(event));
    const result = await pinItem(input);
    if (!result.ok) throw badRequest(result.reason);
    return result;
  })
);

export { pin_post as default };
//# sourceMappingURL=pin.post.mjs.map
