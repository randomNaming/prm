import { c as defineEventHandler, ah as conversationQuery, g as getQuery } from '../../_/nitro.mjs';
import { z } from 'zod';
import { b as conversationMessages, l as listConversations } from '../../_/chat.mjs';
import { g as guarded } from '../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const query = conversationQuery.extend({
  conversationId: z.string().trim().max(36).optional(),
  limit: z.coerce.number().int().min(1).max(200).optional()
});
const conversations = defineEventHandler(
  (event) => guarded(async () => {
    var _a, _b, _c, _d;
    const parsed = query.parse(getQuery(event));
    if (parsed.conversationId) {
      return {
        messages: await conversationMessages(parsed.conversationId, (_a = parsed.limit) != null ? _a : 100)
      };
    }
    return {
      conversations: await listConversations({
        contactId: (_b = parsed.contactId) != null ? _b : null,
        companyId: (_c = parsed.companyId) != null ? _c : null,
        dealId: (_d = parsed.dealId) != null ? _d : null
      })
    };
  })
);

export { conversations as default };
//# sourceMappingURL=conversations.mjs.map
