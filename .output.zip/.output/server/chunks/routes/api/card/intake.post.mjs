import { A as visionCapability, D as createError, E as ensureContact, F as ensureCompany, o as db, q as contacts, n as nowMs, G as recordFact, H as proposeField, C as CONFIG, I as env, J as CARD_VISION_SYSTEM, K as visionModel, L as extractJsonObject, c as defineEventHandler, r as readBody, M as readSession } from '../../../_/nitro.mjs';
import { z } from 'zod';
import { createHash } from 'node:crypto';
import { eq } from 'drizzle-orm';
import { generateText } from 'ai';
import { g as guarded } from '../../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import '@paralleldrive/cuid2';
import '@ai-sdk/openai-compatible';
import 'node:url';

const CARD_FIELD_KEYS = [
  "name",
  "company",
  "title",
  "phone",
  "email",
  "wechat",
  "country",
  "address"
];
const FIELD_TEXT = (max) => z.string().trim().max(max).default("");
const cardFieldsSchema = z.object({
  name: FIELD_TEXT(CONFIG.text.maxNameLength),
  company: FIELD_TEXT(CONFIG.text.maxFieldLength),
  title: FIELD_TEXT(CONFIG.text.maxFieldLength),
  phone: FIELD_TEXT(64),
  email: FIELD_TEXT(CONFIG.text.maxFieldLength),
  wechat: FIELD_TEXT(CONFIG.text.maxFieldLength),
  country: FIELD_TEXT(64),
  address: FIELD_TEXT(CONFIG.text.maxFieldLength)
});
const cardExtraSchema = z.object({
  label: z.string().trim().min(1).max(24),
  value: z.string().trim().min(1).max(CONFIG.text.maxNoteLength),
  evidence: z.string().trim().max(60).default(""),
  confidence: z.number().min(0).max(1).default(0)
});
const cardModelOutputSchema = z.object({
  fields: cardFieldsSchema.nullish().catch(emptyCardFields()),
  extras: z.array(cardExtraSchema).max(8).nullish().catch([]),
  evidence: z.record(z.string(), z.string()).nullish().catch({})
});
function emptyCardFields() {
  return { name: "", company: "", title: "", phone: "", email: "", wechat: "", country: "", address: "" };
}
function badRequestCard(message) {
  return createError({ statusCode: 400, statusMessage: message, data: { code: "bad_request" } });
}
function tooLargeCard(message) {
  return createError({ statusCode: 413, statusMessage: message, data: { code: "too_large" } });
}
const IMAGE_MAGIC = [
  { mime: "image/jpeg", test: (b) => b[0] === 255 && b[1] === 216 && b[2] === 255 },
  { mime: "image/png", test: (b) => b[0] === 137 && b[1] === 80 && b[2] === 78 && b[3] === 71 },
  {
    mime: "image/webp",
    test: (b) => b.subarray(0, 4).toString("latin1") === "RIFF" && b.subarray(8, 12).toString("latin1") === "WEBP"
  }
];
function parseCardImages(raw) {
  const list = z.array(z.string()).min(1).max(CONFIG.card.maxImages).safeParse(raw);
  if (!list.success) {
    throw badRequestCard(`images \u5FC5\u987B\u662F 1 \u5230 ${CONFIG.card.maxImages} \u5F20\u56FE\u7247\u3002`);
  }
  const images = [];
  let totalChars = 0;
  for (const item of list.data) {
    const match = /^data:image\/(jpeg|png|webp);base64,([\s\S]+)$/.exec(item);
    if (!match) throw badRequestCard("\u56FE\u7247\u5FC5\u987B\u662F data:image/jpeg|png|webp \u5F00\u5934\u7684 base64 Data URL\u3002");
    const base64 = match[2].replace(/\s+/g, "");
    if (base64.length > CONFIG.card.maxImageBase64Chars) {
      throw tooLargeCard("\u5355\u5F20\u56FE\u7247\u8FC7\u5927\uFF1Abase64 \u8D85\u8FC7 3MB\u3002");
    }
    const buffer = Buffer.from(base64, "base64");
    if (buffer.length === 0) throw badRequestCard("\u56FE\u7247 base64 \u89E3\u7801\u5931\u8D25\u3002");
    if (buffer.length > env().visionMaxImageBytes) {
      throw tooLargeCard("\u5355\u5F20\u56FE\u7247\u8D85\u8FC7\u89C6\u89C9\u6A21\u578B\u5141\u8BB8\u7684\u5927\u5C0F\u3002");
    }
    const magic = IMAGE_MAGIC.find((entry) => entry.test(buffer));
    if (!magic) throw badRequestCard("\u56FE\u7247\u5185\u5BB9\u4E0D\u662F JPEG/PNG/WebP\uFF08\u6309\u6587\u4EF6\u5934\u5224\u65AD\uFF0C\u4E0D\u542C Content-Type\uFF09\u3002");
    totalChars += base64.length;
    images.push({ mime: magic.mime, base64, buffer, bytes: buffer.length });
  }
  if (totalChars > CONFIG.card.maxTotalBase64Chars) {
    throw tooLargeCard("\u56FE\u7247\u5408\u8BA1\u8FC7\u5927\uFF1Abase64 \u603B\u91CF\u8D85\u8FC7 6MB\u3002");
  }
  return images;
}
function imageHashOf(images) {
  const perImage = images.map((image) => createHash("sha256").update(image.buffer).digest("hex"));
  return createHash("sha256").update(perImage.join("\n")).digest("hex");
}
const deviceWindows = /* @__PURE__ */ new Map();
let globalWindow = [];
function pruneWindow(window, now) {
  const floor = now - CONFIG.card.rateWindowMs;
  while (window.length > 0 && window[0] < floor) window.shift();
  return window;
}
function checkCardRateLimit(deviceId) {
  var _a;
  const now = Date.now();
  globalWindow = pruneWindow(globalWindow, now);
  if (globalWindow.length >= CONFIG.card.rateGlobal) {
    throw createError({
      statusCode: 429,
      statusMessage: "\u5168\u5C40\u63D0\u4EA4\u8FC7\u4E8E\u9891\u7E41\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002",
      data: { code: "rate_limited" }
    });
  }
  const device = pruneWindow((_a = deviceWindows.get(deviceId)) != null ? _a : [], now);
  if (device.length >= CONFIG.card.ratePerDevice) {
    throw createError({
      statusCode: 429,
      statusMessage: `\u8FD9\u53F0\u8BBE\u5907\u63D0\u4EA4\u8FC7\u4E8E\u9891\u7E41\uFF08\u6BCF\u5206\u949F ${CONFIG.card.ratePerDevice} \u6B21\uFF09\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002`,
      data: { code: "rate_limited" }
    });
  }
  device.push(now);
  deviceWindows.set(deviceId, device);
  globalWindow.push(now);
}
function sanitizeEvidence(raw) {
  const out = {};
  for (const key of CARD_FIELD_KEYS) {
    const value = typeof raw[key] === "string" ? raw[key].trim() : "";
    if (value) out[key] = value.slice(0, CONFIG.card.maxEvidenceChars);
  }
  return out;
}
function normalizeCardFields(value) {
  const parsed = cardFieldsSchema.safeParse(value != null ? value : {});
  if (!parsed.success) return emptyCardFields();
  return { ...emptyCardFields(), ...parsed.data };
}
async function recognizeCard(input) {
  var _a, _b;
  const capability = visionCapability();
  if (!capability.enabled) {
    throw createError({
      statusCode: 503,
      statusMessage: capability.reason,
      data: { code: "vision_disabled" }
    });
  }
  const startedAt = Date.now();
  const lines = ["\u8BF7\u8BC6\u522B\u8FD9\u7EC4\u540D\u7247\u56FE\u7247\u5E76\u6309\u7EA6\u5B9A\u8F93\u51FA JSON\u3002"];
  if (input.locale) lines.push(`\u754C\u9762\u8BED\u8A00/\u5730\u533A\uFF1A${input.locale}`);
  if (input.text) lines.push(`\u7AEF\u4E0A\u8865\u5145\u6587\u672C\uFF08OCR \u6216\u624B\u8F93\uFF0C\u53EF\u80FD\u6709\u8BEF\uFF0C\u4EC5\u4F5C\u53C2\u8003\uFF09\uFF1A
${input.text}`);
  const message = {
    role: "user",
    content: [
      // ai v7 推荐 file part 承载图片（mediaType 为 image/*），兼容端仍按 image_url 发出。
      ...input.images.map((image) => ({
        type: "file",
        data: image.buffer,
        mediaType: image.mime
      })),
      { type: "text", text: lines.join("\n") }
    ]
  };
  const result = await generateText({
    model: visionModel(),
    system: CARD_VISION_SYSTEM,
    messages: [message],
    // 失败由 App 重传重试；不做 SDK 层重试，避免 45 秒超时翻倍。
    maxRetries: 0
  });
  const parsed = cardModelOutputSchema.safeParse(extractJsonObject(result.text));
  return {
    fields: normalizeCardFields(parsed.success ? parsed.data.fields : {}),
    extras: parsed.success ? (_a = parsed.data.extras) != null ? _a : [] : [],
    evidence: sanitizeEvidence(parsed.success ? (_b = parsed.data.evidence) != null ? _b : {} : {}),
    rawText: result.text.slice(0, CONFIG.card.maxRawTextChars),
    model: capability.model,
    ms: Date.now() - startedAt
  };
}
const FACT_FIELDS = [
  { key: "title", label: "\u804C\u4F4D" },
  { key: "phone", label: "\u7535\u8BDD" },
  { key: "email", label: "\u90AE\u7BB1" },
  { key: "wechat", label: "\u5FAE\u4FE1\u53F7" },
  { key: "country", label: "\u56FD\u5BB6" },
  { key: "address", label: "\u5730\u5740" }
];
async function intakeCard(input) {
  const capability = visionCapability();
  if (!capability.enabled) {
    throw createError({
      statusCode: 503,
      statusMessage: capability.reason,
      data: { code: "vision_disabled" }
    });
  }
  checkCardRateLimit(input.deviceId);
  const images = parseCardImages(input.images);
  const hash = imageHashOf(images);
  const totalBytes = images.reduce((sum, image) => sum + image.bytes, 0);
  const recognized = await recognizeCard({ images, text: input.text, locale: input.locale });
  const fields = recognized.fields;
  if (!fields.name) {
    throw badRequestCard("\u6CA1\u8BA4\u51FA\u59D3\u540D\uFF1A\u8865\u62CD\u4E00\u5F20\u6E05\u6670\u7684\u6B63\u53CD\u9762\uFF0C\u6216\u5148\u624B\u52A8\u5EFA\u6863\u3002");
  }
  const ensured = await ensureContact({
    name: fields.name,
    phone: fields.phone || null,
    wechatId: fields.wechat || null
  });
  if (fields.company) {
    const company = await ensureCompany(fields.company);
    await db().update(contacts).set({ companyId: company.id, updatedAt: nowMs() }).where(eq(contacts.id, ensured.id));
  }
  const evidenceOf = (quote) => [
    {
      kind: "card.photo",
      quote: (quote || fields.name).slice(0, CONFIG.card.maxEvidenceChars),
      ref: `card:${hash.slice(0, 24)}`,
      time: null
    }
  ];
  const facts = [];
  for (const item of FACT_FIELDS) {
    const value = fields[item.key];
    if (!value) continue;
    facts.push(
      await recordFact({
        contactId: ensured.id,
        field: item.label,
        value,
        evidence: evidenceOf(recognized.evidence[item.key] || value),
        source: "card"
      })
    );
  }
  const proposals = [];
  for (const extra of recognized.extras) {
    const proposed = await proposeField({
      scope: "contact",
      label: extra.label,
      sampleValue: extra.value,
      sampleRef: ensured.id,
      evidence: evidenceOf(extra.evidence || extra.value)
    });
    proposals.push({
      id: proposed.def.id,
      label: proposed.def.label,
      status: proposed.def.status,
      outcome: proposed.outcome,
      value: extra.value
    });
    if (proposed.outcome === "exists" && proposed.def.status === "active") {
      await recordFact({
        contactId: ensured.id,
        field: proposed.def.key,
        value: extra.value,
        evidence: evidenceOf(extra.evidence || extra.value),
        source: "card"
      });
    }
  }
  return {
    ok: true,
    contactId: ensured.id,
    created: ensured.created,
    matchedBy: ensured.matchedBy,
    facts,
    proposals,
    extras: recognized.extras,
    meta: {
      model: recognized.model,
      ms: recognized.ms,
      imageBytes: totalBytes,
      imageHash: `sha256:${hash}`
    }
  };
}

const intakeInput = z.object({
  // 1-2 张，一次综合识别（正面 + 背面/补充信息），不是分两次识别。
  images: z.array(z.string()).min(1, "\u7F3A\u5C11\u56FE\u7247").max(CONFIG.card.maxImages),
  text: z.string().trim().max(CONFIG.card.maxHintTextChars).nullish(),
  locale: z.string().trim().max(16).nullish()
});
const intake_post = defineEventHandler(
  (event) => guarded(async () => {
    var _a, _b, _c;
    if (event.method !== "POST") {
      throw createError({ statusCode: 405, statusMessage: "\u8BE5\u7AEF\u70B9\u53EA\u63A5\u53D7 POST \u8BF7\u6C42\u3002" });
    }
    const parsed = intakeInput.safeParse(await readBody(event));
    if (!parsed.success) {
      throw createError({
        statusCode: 400,
        statusMessage: "\u53C2\u6570\u4E0D\u5BF9\uFF1Aimages \u5FC5\u586B\uFF081-2 \u5F20 data URL \u56FE\u7247\uFF09\u3002",
        data: { code: "bad_request" }
      });
    }
    const claims = await readSession(event);
    return intakeCard({
      deviceId: (_a = claims == null ? void 0 : claims.sub) != null ? _a : "local",
      images: parsed.data.images,
      text: (_b = parsed.data.text) != null ? _b : null,
      locale: (_c = parsed.data.locale) != null ? _c : null
    });
  })
);

export { intake_post as default };
//# sourceMappingURL=intake.post.mjs.map
