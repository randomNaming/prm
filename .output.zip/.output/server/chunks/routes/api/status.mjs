import { c as defineEventHandler, Z as agentCapability, aY as queueStatus, aZ as recentTasks, o as db, q as contacts, a_ as companies } from '../../_/nitro.mjs';
import { inArray } from 'drizzle-orm';
import { g as guarded } from '../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import '@paralleldrive/cuid2';
import 'zod';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const status = defineEventHandler(
  () => guarded(async () => {
    var _a;
    const capability = agentCapability();
    const status = await queueStatus();
    const tasks = await recentTasks(10);
    const contactIds = [...new Set(tasks.map((task) => task.targetType === "contact" ? task.targetId : null).filter((id) => Boolean(id)))];
    const companyIds = [...new Set(tasks.map((task) => task.targetType === "company" ? task.targetId : null).filter((id) => Boolean(id)))];
    const nameById = /* @__PURE__ */ new Map();
    if (contactIds.length > 0) {
      const rows = await db().select({ id: contacts.id, firstName: contacts.firstName, lastName: contacts.lastName }).from(contacts).where(inArray(contacts.id, contactIds));
      for (const row of rows) nameById.set(row.id, `${row.firstName}${(_a = row.lastName) != null ? _a : ""}`);
    }
    if (companyIds.length > 0) {
      const rows = await db().select({ id: companies.id, name: companies.name }).from(companies).where(inArray(companies.id, companyIds));
      for (const row of rows) nameById.set(row.id, row.name);
    }
    return {
      ...status,
      agentEnabled: capability.enabled,
      agentReason: capability.reason,
      model: capability.model,
      tasks: tasks.map((task) => {
        var _a2, _b;
        return { ...task, targetName: (_b = nameById.get((_a2 = task.targetId) != null ? _a2 : "")) != null ? _b : null };
      })
    };
  })
);

export { status as default };
//# sourceMappingURL=status.mjs.map
