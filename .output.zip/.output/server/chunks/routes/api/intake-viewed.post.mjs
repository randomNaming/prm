import { c as defineEventHandler, r as readBody, aL as markIntakeViewed } from '../../_/nitro.mjs';
import { z } from 'zod';
import { g as guarded } from '../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const body = z.object({
  contactId: z.string().trim().min(1).max(36)
});
const intakeViewed_post = defineEventHandler(
  (event) => guarded(async () => {
    const { contactId } = body.parse(await readBody(event));
    return { ok: true, marked: await markIntakeViewed(contactId) };
  })
);

export { intakeViewed_post as default };
//# sourceMappingURL=intake-viewed.post.mjs.map
