import { c as defineEventHandler, am as DEAL_STAGES, an as dealInput, $ as getRouterParam, ao as dealDetail, r as readBody, ap as changeDealStage, aq as updateDeal, ar as archiveDeal } from '../../../_/nitro.mjs';
import { z } from 'zod';
import { g as guarded, n as notFound } from '../../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const stageBody = z.object({
  action: z.literal("stage"),
  stage: z.enum(DEAL_STAGES)
});
const editBody = z.object({
  action: z.literal("edit"),
  deal: dealInput
});
const deleteBody = z.object({ action: z.literal("archive") });
const actionBody = z.discriminatedUnion("action", [stageBody, editBody, deleteBody]);
const _id_ = defineEventHandler(
  (event) => guarded(async () => {
    const id = getRouterParam(event, "id");
    if (!id) throw notFound("\u5546\u673A\u4E0D\u5B58\u5728\u3002");
    if (event.method === "GET") {
      const detail = await dealDetail(id);
      if (!detail) throw notFound("\u5546\u673A\u4E0D\u5B58\u5728\u3002");
      return detail;
    }
    const body = actionBody.parse(await readBody(event));
    if (body.action === "stage") {
      const deal = await changeDealStage(id, body.stage);
      if (!deal) throw notFound("\u5546\u673A\u4E0D\u5B58\u5728\u3002");
      return { deal };
    }
    if (body.action === "edit") {
      const deal = await updateDeal(id, body.deal);
      if (!deal) throw notFound("\u5546\u673A\u4E0D\u5B58\u5728\u3002");
      return { deal };
    }
    const archived = await archiveDeal(id);
    if (!archived) throw notFound("\u5546\u673A\u4E0D\u5B58\u5728\u6216\u5DF2\u5F52\u6863\u3002");
    return { archived: true };
  })
);

export { _id_ as default };
//# sourceMappingURL=_id_.mjs.map
