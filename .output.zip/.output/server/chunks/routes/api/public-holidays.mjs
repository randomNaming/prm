import { aU as COUNTRIES, c as defineEventHandler, g as getQuery } from '../../_/nitro.mjs';
import { b as badRequest } from '../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'zod';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const CACHE_TTL = 12 * 60 * 60 * 1e3;
const cache = /* @__PURE__ */ new Map();
function countryCodeOf(value) {
  var _a, _b, _c, _d, _e, _f;
  const raw = value.trim();
  if (!raw) return null;
  const upper = raw.toUpperCase();
  return (_f = (_e = (_c = (_a = COUNTRIES.find((country) => country.code === upper)) == null ? void 0 : _a.code) != null ? _c : (_b = COUNTRIES.find((country) => country.zh === raw)) == null ? void 0 : _b.code) != null ? _e : (_d = COUNTRIES.find((country) => country.en.toLowerCase() === raw.toLowerCase())) == null ? void 0 : _d.code) != null ? _f : null;
}
async function fetchPublicHolidays(code, year) {
  const key = `${code}-${year}`;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < CACHE_TTL) return hit.items;
  const response = await fetch(`https://date.nager.at/api/v3/PublicHolidays/${year}/${code}`, {
    signal: AbortSignal.timeout(6e3),
    headers: { accept: "application/json" }
  });
  if (!response.ok) throw new Error(`\u516C\u5171\u5047\u671F\u670D\u52A1\u8FD4\u56DE ${response.status}`);
  const raw = await response.json();
  const items = raw.filter((holiday) => holiday.global !== false).map((holiday) => ({
    date: holiday.date,
    name: holiday.name,
    localName: holiday.localName
  })).sort((left, right) => left.date.localeCompare(right.date));
  cache.set(key, { at: Date.now(), items });
  return items;
}

const publicHolidays = defineEventHandler(async (event) => {
  var _a, _b;
  const query = getQuery(event);
  const country = String((_a = query.country) != null ? _a : "").trim();
  const year = Number((_b = query.year) != null ? _b : (/* @__PURE__ */ new Date()).getFullYear());
  if (!country) throw badRequest("\u7F3A\u5C11 country \u53C2\u6570\u3002");
  if (!Number.isInteger(year) || year < 2e3 || year > 2100) {
    throw badRequest("year \u53C2\u6570\u4E0D\u5408\u6CD5\u3002");
  }
  const code = countryCodeOf(country);
  if (!code) {
    return {
      country,
      code: null,
      year,
      holidays: [],
      source: "unavailable",
      reason: "\u8FD9\u4E2A\u56FD\u5BB6\u8FD8\u6CA1\u6709\u5047\u671F\u6570\u636E\u6E90\u3002"
    };
  }
  try {
    const holidays = await fetchPublicHolidays(code, year);
    return { country, code, year, holidays, source: "nager", reason: null };
  } catch {
    return {
      country,
      code,
      year,
      holidays: [],
      source: "unavailable",
      reason: "\u516C\u5171\u5047\u671F\u670D\u52A1\u6682\u65F6\u8FDE\u4E0D\u4E0A\u3002"
    };
  }
});

export { publicHolidays as default };
//# sourceMappingURL=public-holidays.mjs.map
