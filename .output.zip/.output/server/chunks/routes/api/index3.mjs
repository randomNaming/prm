import { c as defineEventHandler, am as DEAL_STAGES, an as dealInput, r as readBody, as as createDeal, g as getQuery, l as listQuery, at as listDeals } from '../../_/nitro.mjs';
import { g as guarded } from '../../_/guard.mjs';
import { z } from 'zod';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const stageFilter = z.enum(DEAL_STAGES).optional();
const index = defineEventHandler(
  (event) => guarded(async () => {
    var _a;
    if (event.method === "POST") {
      const input = dealInput.parse(await readBody(event));
      return { deal: await createDeal(input) };
    }
    const raw = getQuery(event);
    const query = {
      ...listQuery.parse(raw),
      stage: stageFilter.parse((_a = raw.stage) != null ? _a : void 0)
    };
    return listDeals(query);
  })
);

export { index as default };
//# sourceMappingURL=index3.mjs.map
