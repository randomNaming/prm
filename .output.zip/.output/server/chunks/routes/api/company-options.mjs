import { c as defineEventHandler, l as listQuery, g as getQuery, a8 as companyOptions$1 } from '../../_/nitro.mjs';
import { g as guarded } from '../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'zod';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const companyOptions = defineEventHandler(
  (event) => guarded(async () => {
    const query = listQuery.parse(getQuery(event));
    return { items: await companyOptions$1(query.q) };
  })
);

export { companyOptions as default };
//# sourceMappingURL=company-options.mjs.map
