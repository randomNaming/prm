import { c as defineEventHandler, r as readBody, aT as closePromise } from '../../_/nitro.mjs';
import { z } from 'zod';
import { g as guarded, n as notFound } from '../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const body = z.object({
  id: z.string().trim().min(1).max(36),
  action: z.enum(["fulfilled", "cancelled"]),
  note: z.string().trim().max(191).optional()
});
const promiseDecision = defineEventHandler(
  (event) => guarded(async () => {
    var _a;
    const input = body.parse(await readBody(event));
    const result = await closePromise({
      promiseId: input.id,
      action: input.action,
      note: (_a = input.note) != null ? _a : null
    });
    if (!result.ok) throw notFound(result.reason);
    return { ok: true, reason: result.reason };
  })
);

export { promiseDecision as default };
//# sourceMappingURL=promise-decision.mjs.map
