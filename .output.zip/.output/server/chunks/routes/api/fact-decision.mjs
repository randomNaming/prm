import { c as defineEventHandler, r as readBody, au as acceptCompanyFact, av as revertCompanyFact, aw as dismissCompanyFact, ax as acceptFact, ay as revertFact, az as dismissFact } from '../../_/nitro.mjs';
import { z } from 'zod';
import { g as guarded, n as notFound } from '../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const body = z.object({
  id: z.string().trim().min(1).max(36),
  action: z.enum(["accept", "reject", "revert"]),
  subject: z.enum(["contact", "company"]).default("contact")
});
async function decideContactFact(input) {
  if (input.action === "accept") return acceptFact(input.id);
  if (input.action === "revert") return revertFact(input.id);
  return dismissFact(input.id);
}
async function decideCompanyFact(input) {
  if (input.action === "accept") return acceptCompanyFact(input.id);
  if (input.action === "revert") return revertCompanyFact(input.id);
  return dismissCompanyFact(input.id);
}
const factDecision = defineEventHandler(
  (event) => guarded(async () => {
    const input = body.parse(await readBody(event));
    const result = input.subject === "company" ? await decideCompanyFact(input) : await decideContactFact(input);
    if (!result.ok) throw notFound(result.reason);
    return { ok: true, reason: result.reason };
  })
);

export { factDecision as default };
//# sourceMappingURL=fact-decision.mjs.map
