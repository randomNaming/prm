import { c as defineEventHandler } from '../../_/nitro.mjs';
import { b as board$1 } from '../../_/board.mjs';
import { g as guarded } from '../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'zod';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const board = defineEventHandler(
  () => guarded(async () => {
    return board$1();
  })
);

export { board as default };
//# sourceMappingURL=board.mjs.map
