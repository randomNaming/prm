import { c as defineEventHandler, aa as contactInput, r as readBody, ae as createContact, Z as agentCapability, af as enqueueResearch, ag as listContacts, l as listQuery, g as getQuery } from '../../_/nitro.mjs';
import { g as guarded } from '../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'zod';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const index = defineEventHandler(
  (event) => guarded(async () => {
    if (event.method === "POST") {
      const input = contactInput.parse(await readBody(event));
      const contact = await createContact(input);
      if (agentCapability().enabled) {
        await enqueueResearch(contact.id, "\u65B0\u5EFA\u8054\u7CFB\u4EBA\uFF0C\u81EA\u52A8\u89E6\u53D1\u4E00\u6B21\u540E\u53F0\u7814\u7A76\u3002");
      }
      return { contact };
    }
    return listContacts(listQuery.parse(getQuery(event)));
  })
);

export { index as default };
//# sourceMappingURL=index2.mjs.map
