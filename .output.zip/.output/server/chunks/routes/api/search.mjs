import { c as defineEventHandler, C as CONFIG, g as getQuery, aX as searchCrm } from '../../_/nitro.mjs';
import { z } from 'zod';
import { g as guarded } from '../../_/guard.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'mysql2/promise';
import 'drizzle-orm/mysql2';
import 'drizzle-orm/mysql-core';
import 'dotenv';
import 'drizzle-orm';
import '@paralleldrive/cuid2';
import 'ai';
import '@ai-sdk/openai-compatible';
import 'node:url';

const query = z.object({
  q: z.string().trim().max(CONFIG.lists.maxSearchLength).default("")
});
const search = defineEventHandler(
  (event) => guarded(async () => {
    const { q } = query.parse(getQuery(event));
    return { query: q, hits: await searchCrm(q, CONFIG.lists.pageSize * 2) };
  })
);

export { search as default };
//# sourceMappingURL=search.mjs.map
